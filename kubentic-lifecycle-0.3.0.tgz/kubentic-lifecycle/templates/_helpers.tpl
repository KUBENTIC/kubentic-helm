{{/*
Expand the name of the chart.
*/}}
{{- define "kubentic-lifecycle.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels.
*/}}
{{- define "kubentic-lifecycle.labels" -}}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version | replace "+" "_" }}
app.kubernetes.io/name: {{ include "kubentic-lifecycle.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Access token secret name. existingSecret overrides the chart-created one.
*/}}
{{- define "kubentic-lifecycle.tokenSecretName" -}}
{{- if .Values.agent.accessToken.existingSecret -}}
{{- .Values.agent.accessToken.existingSecret -}}
{{- else -}}
kubentic-lifecycle-token
{{- end -}}
{{- end }}

{{/*
Access token secret key.
*/}}
{{- define "kubentic-lifecycle.tokenSecretKey" -}}
{{- if .Values.agent.accessToken.existingSecret -}}
{{- .Values.agent.accessToken.existingKey | default "token" -}}
{{- else -}}
token
{{- end -}}
{{- end }}

{{/*
CRD groups the agent may list (metadata only): live CRDs + rbac.extraCrdGroups.
lookup returns nothing under `helm template` / --dry-run, so only extraCrdGroups apply there.
*/}}
{{- define "kubentic-lifecycle.crdGroups" -}}
{{- $groups := list -}}
{{- range (lookup "apiextensions.k8s.io/v1" "CustomResourceDefinition" "" "").items -}}
{{- $groups = append $groups .spec.group -}}
{{- end -}}
{{- concat $groups .Values.rbac.extraCrdGroups | uniq | sortAlpha | toJson -}}
{{- end }}

{{/*
Job spec shared by the CronJob and the run-on-install Job.
*/}}
{{- define "kubentic-lifecycle.jobSpec" -}}
backoffLimit: {{ .Values.agent.backoffLimit }}
activeDeadlineSeconds: {{ .Values.agent.activeDeadlineSeconds }}
ttlSecondsAfterFinished: {{ .Values.agent.ttlSecondsAfterFinished }}
template:
  metadata:
    labels:
      app.kubernetes.io/name: kubentic-lifecycle-agent
      app.kubernetes.io/instance: {{ .Release.Name }}
  spec:
    serviceAccountName: kubentic-lifecycle-agent
    restartPolicy: Never
    {{- with .Values.agent.imagePullSecrets }}
    imagePullSecrets:
      {{- toYaml . | nindent 6 }}
    {{- end }}
    securityContext:
      runAsNonRoot: true
      runAsUser: 65534
      seccompProfile:
        type: RuntimeDefault
    containers:
      - name: agent
        image: "{{ .Values.agent.image.repository }}:{{ .Values.agent.image.tag | default .Chart.AppVersion }}"
        imagePullPolicy: {{ .Values.agent.image.pullPolicy }}
        env:
          {{- with .Values.agent.clusterName }}
          - name: CLUSTER_NAME
            value: {{ . | quote }}
          {{- end }}
          {{- if .Values.agent.backend.uploadUrl }}
          - name: UPLOAD_ENDPOINT
            value: {{ .Values.agent.backend.uploadUrl | quote }}
          - name: UPLOAD_TOKEN
          {{- else }}
          - name: KUBENTIC_API
            value: {{ required "agent.backend.url is required" .Values.agent.backend.url | quote }}
          - name: KUBENTIC_ACCESS_TOKEN
          {{- end }}
            valueFrom:
              secretKeyRef:
                name: {{ include "kubentic-lifecycle.tokenSecretName" . }}
                key: {{ include "kubentic-lifecycle.tokenSecretKey" . }}
        securityContext:
          allowPrivilegeEscalation: false
          readOnlyRootFilesystem: true
          capabilities:
            drop: [ALL]
        {{- with .Values.agent.resources }}
        resources:
          {{- toYaml . | nindent 10 }}
        {{- end }}
    {{- with .Values.agent.nodeSelector }}
    nodeSelector:
      {{- toYaml . | nindent 6 }}
    {{- end }}
    {{- with .Values.agent.tolerations }}
    tolerations:
      {{- toYaml . | nindent 6 }}
    {{- end }}
    {{- with .Values.agent.affinity }}
    affinity:
      {{- toYaml . | nindent 6 }}
    {{- end }}
{{- end }}
